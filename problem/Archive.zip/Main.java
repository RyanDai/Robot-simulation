package problem;

import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		
		Solution s = new Solution();
		ProblemSpec pS = s.getProblemSpec();

		s.sampling();
		s.generateGraph();
		s.searchGraph(pS.getInitialState());

	}

}
