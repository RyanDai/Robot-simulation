package problem;

import java.awt.geom.Point2D;
import java.io.IOException;
import java.util.*;

import tester.Tester;

public class Solution {
	
	private List<ArmConfig> listConfig;
	/** The initial configuration */
	private ArmConfig initialState;
	/** The goal configuration */
	private ArmConfig goalState;
	/** The obstacles */
	private List<Obstacle> obstacles;
	private int jointCount;
	
	private Tester test;
	private ProblemSpec pS;
	
	private boolean gripper;

	public Solution(){
		test = new Tester();
		pS = new ProblemSpec();
		
		try {
			pS.loadProblem("4_joints.txt");
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		this.initialState = pS.getInitialState();
		this.goalState = pS.getGoalState();
		this.jointCount = pS.getJointCount();
		this.gripper = pS.getGripper();
		this.obstacles = pS.getObstacles();
		
		
		listConfig = new ArrayList<ArmConfig>();
	}
	
	
	public void sampling() {
		int Nodes = 300;
		ArmConfig node;
		String config;
		Random rd = new Random();
		listConfig.add(initialState);
		listConfig.add(goalState);

		
		while (Nodes > 0) {
			ArrayList<Double> joints = new ArrayList<Double>();
			StringBuilder str = new StringBuilder();
			int count = jointCount;
 
			joints.add((double) (Math.round(rd.nextDouble() * 1000)) / 1000);
			joints.add((double) (Math.round(rd.nextDouble() * 1000)) / 1000);

			while (count > 0) {
				joints.add((double) (Math.round(rd.nextDouble() * 1000)) / 1000);
				count--;
			}
			for (double ele : joints) {
				str.append(ele);
				str.append(" ");
			}
			config = str.toString();

			node = new ArmConfig(config, gripper);		
			
			if (listConfig.contains(node) || test.hasCollision(node, obstacles) || test.hasSelfCollision(node) || !test.fitsBounds(node)) {				
				Nodes++;			
			} else {
				listConfig.add(node);
			}
			Nodes--;
		}
	}

	public boolean validPath(ArmConfig node1, ArmConfig node2) {
		// how to get path between 2 nodes
		if(test.isValidStep(node1, node2)){
			return true;
		} 
		else{
			double xcor = (node1.getBaseCenter().getX() + node2.getBaseCenter().getX())/2;
			double ycor = (node1.getBaseCenter().getY() + node2.getBaseCenter().getY())/2;
			Point2D newBase = new Point2D.Double(xcor, ycor);
			ArrayList<Double> jointList = new ArrayList<Double>();
			for(int i =0; i < node1.getJointCount(); i++){
				double newJoint = (node1.getJointAngles().get(i) + node2.getJointAngles().get(i))/2;
				jointList.add(newJoint);
			}
			ArmConfig temp = new ArmConfig(newBase, jointList);
			if(test.hasCollision(temp, obstacles) || test.hasSelfCollision(temp) || !test.fitsBounds(temp)){
				return false;
			}
			validPath(node1, temp);
			validPath(temp, node2);
		}
		return true;
	}
	
	public void generateGraph(){
		for(int i = 0; i < listConfig.size(); i++){
			for(int j = 0; j < listConfig.size(); j++){
				if(listConfig.get(i).maxDistance(listConfig.get(j)) < 0.15){
					if(validPath(listConfig.get(i), listConfig.get(j))){
						listConfig.get(i).adjacencies.add(new Edge(listConfig.get(j)));
					}
				}
			}
		}
	}
	
	public void searchGraph(ArmConfig initial){
		Queue<ArmConfig> queue = new LinkedList<ArmConfig>();
		Set<ArmConfig> explored = new HashSet<ArmConfig>();
		queue.add(initial);
		/*for(int i = 0; i < listConfig.size(); i++){
			System.out.println(listConfig.get(0).adjacencies + "\n");
		}*/
		//System.out.println(initial.adjacencies + "\n");
		while(!queue.isEmpty()){
			ArmConfig current = queue.poll();
			explored.add(current);
			 
			if(current.toString().equals(goalState.toString())){
				//System.out.println("here\n");
				List<ArmConfig> path = printPath(goalState);
				for(int i = 0; i < path.size(); i++){
					System.out.println(path.get(i));
				}
				return;
			}
			if(current.adjacencies != null){
				for(Edge e: current.adjacencies){	            	
	                ArmConfig child = e.target;     
	                if(!explored.contains(child) && !queue.contains(child)){
	                    child.parent = current;
	                    queue.add(child);
	                }
				}
			}
		}
	}
	
	public static List<ArmConfig> printPath(ArmConfig target){
        List<ArmConfig> path = new ArrayList<ArmConfig>();
        for(ArmConfig node = target; node!=null; node = node.parent){
            path.add(node);
        }
        Collections.reverse(path);
        return path;
    }
	
	public ProblemSpec getProblemSpec(){
		return pS;
	}

}
